<template>
	<view class="content">
		<view class="content-c">
			<view class="content-c-top color-6 fsz28">
				将网站分享给您的好友，您的好友通过您的分享购买网站商品，你将会获得佣金。
			</view>
			<image class="qrcode-img" src="/static/demo-img/qcode.png" mode="widthFix"></image>
			<view class="color-3 fsz26">
				长按保存二维码图片
			</view>
		</view>
	</view>
</template>

<script>
</script>

<style>
.content-c{
	text-align: center;
	padding: 50upx 0;
	width: 80%;
	margin: 0 auto;
}
.content-c-top{
	text-align: left;
}
.qrcode-img{
	width: 400upx;
	height: 400upx;
	margin: 50upx auto;
}
</style>
