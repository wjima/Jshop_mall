<template>
    <div>
        方式点击客服接待室
    </div>
</template>

<script>
export default {
    name: "StoreOrder"
}
</script>

<style scoped>

</style>
