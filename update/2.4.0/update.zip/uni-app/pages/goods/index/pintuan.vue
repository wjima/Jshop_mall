<template>
	<view class="content">
		<hx-navbar :fixed="true" :title="barTitle" barPlaceholder="hidden" transparent="auto" color="#000000"
		 :background-color="[[255, 255, 255],[255, 255, 255]]" :pageScroll.sync="scrollData">
		</hx-navbar>
		<!-- <view class="nav-back">
			<view class="back-btn" @click="backBtn()">
				<image class="icon" src="/static/image/back-black.png" mode=""></image>
			</view>
		</view> -->

		<view class="content-top">
			<!-- 轮播图 -->
			<view class="swiper">
				<swiper class="swiper-c" :indicator-dots="swiper.indicatorDots" :autoplay="swiper.autoplay" :interval="swiper.interval"
				 :duration="swiper.duration">
					<swiper-item class="have-none" v-for="(item, index) in goodsInfo.album" :key="index" @click="clickImg(item)">
						<!-- {{goodsInfo.album}} -->
						<image class="" :src="item" mode="aspectFill"></image>
					</swiper-item>
				</swiper>
			</view>
			<!-- 轮播图end -->

			<view class="cell-group">
				<!-- 倒计时 -->
				<view class="price-salesvolume" v-if="lasttime.hour !== false">
					<view class="commodity-price">
						<text class="current-price">￥{{ pintuanPrice || '0.00' }}</text>
						<text class="cost-price">￥{{ product.mktprice || '0.00' }}</text>
					</view>
					<view class="commodity-salesvolume">
						<text>已售{{ goodsInfo.buy_pintuan_count || '0' }}件/剩余{{ product.stock || '0' }}件</text>
						<text>累计销售{{ goodsInfo.buy_count || '0' }}件</text>
						<text>{{ goodsInfo.pintuan_rule.people_number || '0' }}人成团</text>
					</view>

					<view class="commodity-time" v-if="goodsInfo.pintuan_rule.pintuan_start_status == 1">
						<text>距结束仅剩</text>
						<view class="commodity-day">
							<uni-countdown textColor="#fce250" :day="lasttime.day" :hour="lasttime.hour" :minute="lasttime.minute" :second="lasttime.second"></uni-countdown>
						</view>
					</view>

					<view class="commodity-time" v-if="goodsInfo.pintuan_rule.pintuan_start_status == 2">
						<text>即将开团</text>
						<view class="commodity-day">
							<uni-countdown textColor="#fce250" :day="goodsInfo.pintuan_rule.lasttime.day" :hour="goodsInfo.pintuan_rule.lasttime.hour"
							 :minute="goodsInfo.pintuan_rule.lasttime.minute" :second="goodsInfo.pintuan_rule.lasttime.second"></uni-countdown>
						</view>
					</view>
					<view class="commodity-time-img"></view>
					<!-- <view class='commodity-time'>
						已结束
					</view> -->
				</view>
				<!-- 倒计时end -->

				<!-- 分享 -->
				<view class="cell-item goods-details">
					<view class="cell-item-hd">
						<view class="cell-hd-title">
							<view class="color-3 fsz28 cell-hd-title-view">{{ product.name || '' }}</view>
							<view v-if="goodsInfo.brief" class="color-9 fsz24 cell-hd-title-view">{{ goodsInfo.brief || '' }}</view>
						</view>
					</view>
					<view class="cell-item-ft">
						<image class="cell-ft-next icon" @click="goShare()" src="/static/image/share.png"></image>
					</view>
				</view>
				<!-- 分享end -->

				<!-- 促销 -->
				<view class="cell-item goods-title-item cell-item-mid" v-if="promotion.length">
					<view class="cell-item-hd">
						<view class="cell-hd-title">促销</view>
					</view>
					<view class="cell-item-bd">
						<view class="romotion-tip">
							<view class="romotion-tip-item" :class="item.type !== 2 ? 'bg-gray' : ''" v-for="(item, index) in promotion"
							 :key="index">{{ item.name || item ||'' }}</view>
						</view>
					</view>
				</view>
				<!-- 促销end -->

				<!-- 规格 -->
				<view class="cell-item goods-title-item cell-item-mid" v-if="isSpes">
					<view class="cell-item-hd">
						<view class="cell-hd-title">规格</view>
					</view>
					<view class="cell-item-bd" @click="toshow(1)">
						<text class="cell-bd-text">{{ product.spes_desc || '' }}</text>
					</view>
				</view>
				<!-- 规格end -->

				<!-- 说明 -->
				<view class="cell-item goods-title-item cell-item-mid" v-if="goodsShowWord && goodsShowWord != ''">
					<view class="cell-item-hd">
						<view class="cell-hd-title">说明</view>
					</view>
					<view class="cell-item-bd">
						<view class="cell-bd-view" v-for="(item, index) in goodsShowWord" :key="index">
							<image class="goods-title-item-ic" src="/static/image/ic-dui.png" mode=""></image>
							<view class="cell-bd-text">{{ item }}</view>
						</view>
					</view>
				</view>
				<!-- 说明end -->
			</view>

			<!-- 团购拼单 -->
			<view class="cell-group margin-cell-group" v-if="pintuanRecord.length > 0">
				<view class="cell-item right-img">
					<view class="cell-item-hd">
						<view class="cell-hd-title">{{ teamCount || '0' }}人在拼单，可直接参与</view>
					</view>
				</view>
				<view class="group-swiper">
					<swiper class="group-swiper-c" :class="groupHeight" :indicator-dots="indicatorDots" :autoplay="autoplay" vertical="true"
					 circular="true" :interval="interval" :duration="duration">
						<swiper-item v-for="(item, index) in pintuanRecord" :key="index">
							<view class="swiper-item">
								<view class="cell-item">
									<view class="cell-item-hd">
										<image class="user-head-img cell-hd-icon have-none" :src="item[0].user_avatar" mode=""></image>
										<view class="cell-hd-title">{{ item[0].nickname || '' }}</view>
									</view>
									<view class="cell-item-bd">
										<view class="cell-bd-view">
											<text class="cell-bd-text">
												还差
												<text class="red-price">{{ item[0].team_nums || '' }}人</text>
												拼成
											</text>
										</view>
										<view class="cell-bd-view">
											<view class="commodity-day">
												<text class="fsz24 color-6">剩余：</text>
												<uni-countdown color="#666" :day="item[0].remainder_time.day" :hour="item[0].remainder_time.hour" :minute="item[0].remainder_time.minute"
												 :second="item[0].remainder_time.second"></uni-countdown>
											</view>
										</view>
									</view>
									<view class="cell-item-ft"><button class="btn" @click="toshow(2, item[0].team_id)">去拼单</button></view>
								</view>
								<view class="cell-item" v-if="item[1]">
									<view class="cell-item-hd">
										<image class="user-head-img cell-hd-icon have-none" :src="item[1].user_avatar" mode=""></image>
										<view class="cell-hd-title">{{ item[1].nickname || '' }}</view>
									</view>
									<view class="cell-item-bd">
										<view class="cell-bd-view">
											<text class="cell-bd-text">
												还差
												<text class="red-price">{{ item[1].team_nums || '' }}人</text>
												拼成
											</text>
										</view>
										<view class="cell-bd-view">
											<view class="commodity-day">
												<text class="fsz24 color-6">剩余：</text>
												<uni-countdown color="#666" :day="item[1].remainder_time.day" :hour="item[1].remainder_time.hour" :minute="item[1].remainder_time.minute"
												 :second="item[1].remainder_time.second"></uni-countdown>
											</view>
										</view>
									</view>
									<view class="cell-item-ft"><button class="btn" @click="toshow(2, item[1].id)">去拼单</button></view>
								</view>
							</view>
						</swiper-item>
					</swiper>
				</view>
			</view>
			<view class="cell-group margin-cell-group" v-else>
				<view class="cell-item right-img">
					<view class="cell-item-hd">
						<view class="cell-hd-title">暂无开团信息</view>
					</view>
				</view>
			</view>

			<view class="goods-content">
				<uni-segmented-control :current="current" :values="items" @clickItem="onClickItem" style-type="text" active-color="#333"></uni-segmented-control>
				<view class="goods-content-c">
					<view class="goods-detail" v-if="current === 0">
						<jshopContent :content="goodsInfo.intro" v-if="goodsInfo.intro"></jshopContent>
						<view class="comment-none" v-else>
							<image class="comment-none-img" src="/static/image/order.png" mode=""></image>
						</view>
					</view>
					<view class="goods-parameter" v-else-if="current === 1">
						<view class="cell-group" v-if="goodsParams.length">
							<view class="cell-item" v-for="(item, index) in goodsParams" :key="index">
								<view class="cell-item-hd">
									<view class="cell-hd-title">{{ item.name || '' }}</view>
								</view>
								<view class="cell-item-bd">
									<text class="cell-bd-text">{{ item.value || '' }}</text>
								</view>
							</view>
						</view>
						<view class="comment-none" v-else>
							<image class="comment-none-img" src="/static/image/order.png" mode=""></image>
						</view>
					</view>
					<view class="goods-assess" v-else-if="current === 2">
						<view v-if="goodsComments.list.length">
							<view class="goods-assess-item" v-for="(item, index) in goodsComments.list" :key="index">
								<view class="cell-group">
									<view class="cell-item goods-title-item">
										<view class="cell-item-hd">
											<image class="user-head-img" :src="item.user.avatar" mode="aspectFill"></image>
										</view>
										<view class="cell-item-bd">
											<view class="cell-bd-view">
												<text class="cell-bd-text">{{ item.user.nickname || '' }}</text>
												<view class="cell-bd-text-right">
													<uni-rate size="16" disabled="true" :value="item.score"></uni-rate>
												</view>
											</view>
											<view class="cell-bd-view">
												<text class="cell-bd-text color-9" style="margin-right: 16upx;">{{ item.ctime || '' }}</text>
												<text class="cell-bd-text color-9">{{ item.addon || '' }}</text>
											</view>
										</view>
									</view>
								</view>
								<view class="gai-body">
									<view class="gai-body-text">{{ item.content || '' }}</view>
									<view class="gai-body-img" v-if="item.images_url.length">
										<image :src="img" mode="aspectFill" v-for="(img, key) in item.images_url" :key="key" @click="clickImg(img)"></image>
									</view>
									<view class="seller-content" v-if="item.seller_content">
										<view class="seller-content-top">
											<image class="seller-content-img" src="/static/image/seller-content.png"></image>
											掌柜回复
										</view>
										{{ item.seller_content || '' }}
									</view>
								</view>
							</view>
							<uni-load-more :status="goodsComments.loadStatus"></uni-load-more>
						</view>
						<view class="comment-none" v-else>
							<image class="comment-none-img" src="/static/image/order.png" mode=""></image>
						</view>
					</view>
				</view>
			</view>
		</view>

		<lvv-popup position="bottom" ref="pintuanpop">
			<view class="ig-top" v-if="teamInfo.list.length > 0">
				<view class="ig-top-t">
					<view class="">
						剩余时间：
						<uni-countdown :day="teamInfo.team_time.day" :hour="teamInfo.team_time.hour" :minute="teamInfo.team_time.minute"
						 :second="teamInfo.team_time.second"></uni-countdown>
					</view>
				</view>
				<view class="ig-top-m">
					<view class="user-head-img-c" v-for="(item, index) in teamInfo.list" :key="index">
						<view class="user-head-img-tip" v-if="item.id == item.team_id">拼主</view>
						<image class="user-head-img cell-hd-icon have-none" :src="item.user_avatar" mode=""></image>
					</view>
					<view class="user-head-img-c uhihn" v-if="teamInfo.team_nums" v-for="n in teamInfo.team_nums" :key="n"><text>?</text></view>
				</view>
				<view class="ig-top-b">
					<view class="igtb-top">
						还差
						<text class="red-price">{{ teamInfo.team_nums || '' }}</text>
						人，赶快拼单吧
					</view>
					<view class="igtb-mid"><button class="btn" @click="toshow(2, teamInfo.id)" v-if="teamInfo.team_nums && teamInfo.team_nums > 0">参与拼团</button></view>
				</view>
			</view>
		</lvv-popup>

		<lvv-popup position="bottom" ref="share" v-if="goodsId">
			<!-- #ifdef H5 -->
			<shareByH5 :shareType="3" :goodsId="goodsId" :shareImg="goodsInfo.image_url" :shareTitle="goodsInfo.name"
			 :shareContent="goodsInfo.brief" :shareHref="shareHref" @close="closeShare()"></shareByH5>
			<!-- #endif -->

			<!-- #ifdef MP-WEIXIN -->
			<shareByWx :shareType="3" :goodsId="goodsId" :shareImg="goodsInfo.image_url" :shareTitle="goodsInfo.name"
			 :shareContent="goodsInfo.brief" :shareHref="shareHref" @close="closeShare()"></shareByWx>
			<!-- #endif -->

			<!-- #ifdef MP-ALIPAY -->
			<shareByAli :shareType="3" :goodsId="goodsId" :shareImg="goodsInfo.image_url" :shareTitle="goodsInfo.name"
			 :shareContent="goodsInfo.brief" :shareHref="shareHref" @close="closeShare()"></shareByAli>
			<!-- #endif -->

			<!-- #ifdef MP-TOUTIAO -->
			<shareByTt :shareType="3" :goodsId="goodsId" :shareImg="goodsInfo.image_url" :shareTitle="goodsInfo.name"
			 :shareContent="goodsInfo.brief" :shareHref="shareHref" @close="closeShare()"></shareByTt>
			<!-- #endif -->

			<!-- #ifdef APP-PLUS || APP-PLUS-NVUE -->
			<shareByApp :shareType="3" :goodsId="goodsId" :shareImg="goodsInfo.image_url" :shareTitle="goodsInfo.name"
			 :shareContent="goodsInfo.brief" :shareHref="shareHref" @close="closeShare()"></shareByApp>
			<!-- #endif -->
		</lvv-popup>

		<!-- 弹出层 -->
		<lvv-popup position="bottom" ref="lvvpopref">
			<view style="width: 100%;max-height: 804upx;background: #FFFFFF;position: absolute;left:0;bottom: 0;">
				<view class="pop-c">
					<view class="pop-t">
						<view class="goods-img">
							<image :src="product.image_path" mode="aspectFill"></image>
						</view>
						<view class="goods-information">
							<view class="pop-goods-name">{{ product.name || '' }}</view>
							<view class="pop-goods-price red-price">￥ {{ price || '' }}</view>
						</view>
						<view class="close-btn" @click="toclose()">
							<image src="/static/image/close.png"></image>
						</view>
					</view>
					<scroll-view class="pop-m" scroll-y="true" style="max-height: 560upx;">
						<spec :spesData="product.default_spes_desc" ref="spec" @changeSpes="changeSpes"></spec>

						<view class="goods-number">
							<text class="pop-m-title">数量</text>
							<view class="pop-m-bd-in">
								<uni-number-box :min="minNums" :max="product.stock" :value="buyNum" @change="bindChange"></uni-number-box>
							</view>
						</view>
					</scroll-view>
					<view class="pop-b">
						<button class="btn btn-square btn-b btn-all" hover-class="btn-hover2" @click="buyNow()" v-if="product.stock">确定</button>
						<button class="btn btn-square btn-g btn-all" v-else>已售罄</button>
					</view>
				</view>
			</view>
		</lvv-popup>
		<!-- 弹出层end -->

		<div id="qrCode" ref="qrCodeDiv"></div>
		<!-- 底部按钮 -->
		<view class="goods-bottom">
			<!-- 客服按钮 -->
			<!-- #ifdef H5 || APP-PLUS-NVUE || APP-PLUS -->
			<view class="goods-bottom-ic" @click="showChat()">
				<image class="icon" src="/static/image/customerservice.png" mode=""></image>
				<view>客服</view>
			</view>
			<!-- #endif -->
			<!-- #ifdef MP-WEIXIN -->
			<button class="goods-bottom-ic weiContact" hover-class="none" open-type="contact" bindcontact="showChat"
			 :session-from="kefupara">
				<image class="icon" src="/static/image/customerservice.png" mode=""></image>
				<view>客服</view>
			</button>
			<!-- #endif -->
			<!-- #ifdef MP-ALIPAY -->
			<contact-button class="goods-bottom-ic icon" icon="/static/image/customerservice.png" size="80rpx*80rpx" tnt-inst-id="WKPKUZXG"
			 scene="SCE00040186" hover-class="none" />
			<!-- #endif -->
			<!-- #ifdef MP-TOUTIAO -->
			<view class="goods-bottom-ic" @click="showChat()">
				<image class="icon" src="/static/image/customerservice.png" mode=""></image>
				<view>客服</view>
			</view>
			<!-- #endif -->

			<view class="goods-bottom-ic" @click="collection">
				<image class="icon" :src="isfav ? favLogo[1] : favLogo[0]" mode=""></image>
				<view v-if="!isfav">收藏</view>
				<view v-if="isfav">已收藏</view>
			</view>

			<view class="goods-bottom-ic" @click="redirectCart">
				<view class="badge color-f" v-if="cartNums">{{ cartNums || '' }}</view>
				<image class="icon" src="/static/image/ic-me-car.png" mode=""></image>
				<view>购物车</view>
			</view>

			<button class="btn btn-square btn-g" @click="toshow(1)" hover-class="btn-hover2">
				<view class="btn-content">
					<view class="color-6">￥{{ product.price || '' }}</view>
					<view class="color-6 fsz24">单独购买</view>
				</view>
			</button>

			<button class="btn btn-square btn-b" @click="toshow(2)" hover-class="btn-hover2" v-if="goodsInfo.pintuan_rule.pintuan_start_status == 1">
				<view class="btn-content">
					<view class="">￥{{ pintuanPrice || '' }}</view>
					<view class="fsz24">发起拼团</view>
				</view>
			</button>

			<button class="btn btn-square btn-b" hover-class="btn-hover2" v-if="goodsInfo.pintuan_rule.pintuan_start_status == 2">
				<view class="btn-content">
					<view class="">￥{{ pintuanPrice || '' }}</view>
					<view class="fsz24">即将开团</view>
				</view>
			</button>

			<button class="btn btn-square btn-b" hover-class="btn-hover2" v-if="goodsInfo.pintuan_rule.pintuan_start_status == 3">
				<view class="btn-content">
					<view class="">￥{{ pintuanPrice || '' }}</view>
					<view class="fsz24">拼团已结束</view>
				</view>
			</button>
		</view>
		<!-- 底部按钮end -->

		<!-- 右边浮动球 -->
		<uni-fab :pattern="pattern" :content="content" :horizontal="horizontal" :vertical="vertical" :direction="direction"
		 @trigger="trigger"></uni-fab>
	</view>
</template>

<script>
	import uniSegmentedControl from '@/components/uni-segmented-control/uni-segmented-control.vue';
	import lvvPopup from '@/components/lvv-popup/lvv-popup.vue';
	import uniNumberBox from '@/components/uni-number-box/uni-number-box.vue';
	import uniRate from '@/components/uni-rate/uni-rate.vue';
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import uniFab from '@/components/uni-fab/uni-fab.vue';
	import {
		get
	} from '@/config/db.js';
	import {
		apiBaseUrl
	} from '@/config/config.js';
	import uniCountdown from '@/components/uni-countdown/uni-countdown.vue';
	import spec from '@/components/spec/spec.vue';
	// #ifdef H5
	import shareByH5 from '@/components/share/shareByh5.vue';
	// #endif
	// #ifdef MP-WEIXIN
	import shareByWx from '@/components/share/shareByWx.vue';
	// #endif
	// #ifdef MP-TOUTIAO
	import shareByTt from '@/components/share/shareByTt.vue';
	// #endif
	// #ifdef MP-ALIPAY
	import shareByAli from '@/components/share/shareByAli.vue';
	// #endif
	// #ifdef APP-PLUS || APP-PLUS-NVUE
	import shareByApp from '@/components/share/shareByApp.vue';
	// #endif
	import jshopContent from '@/components/jshop/jshop-content.vue'; //视频和文本解析组件
	export default {
		components: {
			uniSegmentedControl,
			lvvPopup,
			uniNumberBox,
			uniRate,
			uniLoadMore,
			uniFab,
			uniCountdown,
			spec,
			jshopContent,
			// #ifdef H5
			shareByH5,
			// #endif
			// #ifdef MP-WEIXIN
			shareByWx,
			// #endif
			// #ifdef MP-TOUTIAO
			shareByTt,
			// #endif
			// #ifdef MP-ALIPAY
			shareByAli,
			// #endif
			// #ifdef APP-PLUS || APP-PLUS-NVUE
			shareByApp
			// #endif
		},
		data() {
			return {
				scrollData: {},
				barTitle: '',
				swiper: {
					indicatorDots: true,
					autoplay: true,
					interval: 3000,
					duration: 800
				}, // 轮播图属性设置
				items: ['图文详情', '商品参数', '买家评论'],
				current: 0, // init tab位
				goodsId: 0, // 商品id
				groupId: 0, // 团购ID
				goodsInfo: {
					pintuan_rule: {
						pintuan_start_status: 1
					}
				}, // 商品详情
				cartNums: 0, // 购物车数量
				product: {}, // 规格详情
				goodsParams: [], // 商品参数信息
				goodsComments: {
					loadStatus: 'more',
					page: 1,
					limit: 5,
					list: []
				}, // 商品评论信息
				buyNum: 1, // 选定的购买数量
				minBuyNum: 1, // 最小可购买数量
				type: 2, // 1单独购买 2拼团
				isfav: false, // 商品是否收藏
				favLogo: ['/static/image/ic-me-collect.png', '/static/image/ic-me-collect2.png'],
				horizontal: 'right', //右下角弹出按钮
				vertical: 'bottom',
				direction: 'vertical',
				pattern: {
					color: '#7A7E83',
					backgroundColor: '#fff',
					selectedColor: '#007AFF',
					buttonColor: '#FF7159'
				},
				content: [{
						iconPath: '/static/image/tab-ic-hom-selected.png',
						selectedIconPath: '/static/image/tab-ic-hom-unselected.png',
						// text: '首页',
						active: false,
						url: '/pages/index/index'
					},

					{
						iconPath: '/static/image/tab-ic-me-selected.png',
						selectedIconPath: '/static/image/tab-ic-me-unselected.png',
						// text: '个人中心',
						active: false,
						url: '/pages/member/index/index'
					}
				],
				indicatorDots: false,
				autoplay: false,
				interval: 2000,
				duration: 500,
				lasttime: {
					day: 0,
					hour: false,
					minute: 0,
					second: 0
				}, //购买倒计时
				pintuanPrice: 0,
				discount_amount: 0, //拼团优惠金额
				price: 0,
				teamCount: 0, //已经有多少人拼团
				pintuanRecord: [], //拼团列表
				remainder_time: {
					day: 0,
					hour: false,
					minute: 0,
					second: 0
				}, //拼团倒计时
				groupHeight: 'groupHeight',
				teamId: 0, //去参团的teamid
				teamInfo: {
					list: [],
					team_time: {
						day: 0,
						hour: 0,
						minute: 0,
						second: 0
					} //被邀请拼团倒计时
				},
				shareUrl: '/pages/share/jump',
				userInfo: {}, // 用户信息
				kefupara: '', //客服传递资料
			};
		},
		onLoad(e) {
			this.goodsId = e.id - 0;
			if (e.team_id) {
				this.teamId = e.team_id - 0;
				// this.getTeam(this.teamId);
			}
			if (this.goodsId) {
				this.getGoodsInfo();
				this.getGoodsParams();
				this.getGoodsComments();
			} else {
				this.$common.errorToShow('获取失败', () => {
					uni.navigateBack({
						delta: 1
					});
				});
			}

			// 获取购物车数量
			this.getCartNums();
		},
		onShow() {
			if(this.teamId){
				this.getTeam(this.teamId);
			}
		},
		computed: {
			// 规格切换计算规格商品的 可购买数量
			minNums() {
				return this.product.stock > this.minBuyNum ? this.minBuyNum : this.product.stock;
			},
			// 判断商品是否是多规格商品  (为了兼容小程序 只能写在计算属性里面了)
			isSpes() {
				if (this.product.hasOwnProperty('default_spes_desc') && Object.keys(this.product.default_spes_desc).length) {
					return true;
				} else {
					return false;
				}
			},
			// 优惠信息重新组装
			promotion() {
				let arr = [];
				if (this.product.promotion_list) {
					for (let k in this.product.promotion_list) {
						arr.push(this.product.promotion_list[k]);
					}
				}
				return arr;
			},
			shareHref() {
				let pages = getCurrentPages();
				let page = pages[pages.length - 1];
				// #ifdef H5 || MP-WEIXIN || APP-PLUS || APP-PLUS-NVUE
				return apiBaseUrl + 'wap/' + page.route + '?id=' + this.goodsId + '&group_id=' + this.groupId;
				// #endif

				// #ifdef MP-ALIPAY
				return apiBaseUrl + 'wap/' + page.__proto__.route + '?id=' + this.goodsId + '&group_id=' + this.groupId;
				// #endif
			},
			// 获取店铺联系人手机号
			shopMobile() {
				return this.$store.state.config.shop_mobile || 0;
			},

			goodsShowWord() {
				return this.$store.state.config.goods_show_word;
			}
		},
		onReachBottom() {
			if (this.current === 2 && this.goodsComments.loadStatus === 'more') {
				this.getGoodsComments();
			}
		},
		methods: {
			// 返回上一页
			backBtn() {
				var pages = getCurrentPages();
				if (pages.length > 1) {
					uni.navigateBack({
						delta: 1
					});
				} else {
					uni.switchTab({
						url: '/pages/index/index'
					});
				}
			},
			// 获取商品详情
			getGoodsInfo() {
				let data = {
					id: this.goodsId
				};
				// 如果用户已经登录 要传用户token
				let userToken = get('userToken');
				if (userToken) {
					data['token'] = userToken;
				}
				let _this = this;
				_this.$api.pintuanGoodsInfo(data, res => {
					//console.log(res);
					if (res.status) {
						let info = res.data;
						_this.goodsInfo = info;
						let products = res.data.product;
						_this.discount_amount = parseFloat(info.pintuan_rule.discount_amount).toFixed(2);
						_this.product = _this.spesClassHandle(products);
						_this.isfav = _this.goodsInfo.isfav === 'true' ? true : false;

						// debugger;
						_this.pintuanPrice = this.$common.moneySub(_this.product.price, _this.discount_amount);

						let timestamp = Date.parse(new Date()) / 1000;

						let lasttime = res.data.pintuan_rule.etime - timestamp;
						_this.lasttime = _this.$common.timeToDateObj(lasttime);
						// 获取拼团记录
						let pintuan_data = info.pintuan_record;
						let new_data = new Array();
						for (var k = 0; k < pintuan_data.length; k++) {
							pintuan_data[k].remainder_time = _this.$common.timeToDateObj(pintuan_data[k].close_time - timestamp);
							if (k == 0 || k % 2 == 0) {
								if (k + 1 < pintuan_data.length) {
									var a = [pintuan_data[k], pintuan_data[k + 1]];
								} else {
									var a = [pintuan_data[k]];
								}
								new_data.push(a);
							}
						}
						pintuan_data.length < 2 ? (_this.groupHeight = 'groupHeight') : (_this.groupHeight = '');
						_this.pintuanRecord = new_data;

						_this.teamCount = info.pintuan_record_nums;
						// 判断如果登录用户添加商品浏览足迹
						if (userToken) {
							_this.goodsBrowsing();
						}
					} else {
						var pages = getCurrentPages();
						_this.$common.errorToShow(res.msg, () => {
							if (pages.length > 1) {
								uni.navigateBack({
									delta: 1
								});
							} else {
								uni.switchTab({
									url: '/pages/index/index'
								});
							}
						});
					}
				});
			},
			// 获取通过分享进来的拼团数据
			getTeam(id) {
				// console.log(id);
				this.$api.getOrderPintuanTeamInfo({
						team_id: id
					},
					res => {
						if (res.status) {
							console.log(res);
							this.teamInfo = {
								list: res.data.teams,
								current_count: res.data.teams.length,
								people_number: res.data.people_number,
								team_nums: res.data.team_nums, //剩余
								close_time: res.data.close_time, //关闭时间
								id: res.data.id, //拼团id
								team_id: res.data.team_id, //拼团团队id
								rule_id: res.data.rule_id,
								status: res.data.status
							};
							let timestamp = Date.parse(new Date()) / 1000;
							this.teamInfo.team_time = this.$common.timeToDateObj(res.data.close_time - timestamp);
							if (res.data.status == 1) {
								this.pintuanShow();
							} else {
								this.teamId = 0;
							}
						} else {
							this.$common.errorToShow(res.msg);
						}
					}
				);
			},
			// 获取购物车数量
			getCartNums() {
				let userToken = this.$db.get('userToken');
				if (userToken && userToken != '') {
					// 获取购物车数量
					this.$api.getCartNum({}, res => {
						if (res.status) {
							this.cartNums = res.data;
						}
					});
				}
			},
			// 显示modal弹出框
			toshow(type, team_id) {
				this.type = type;
				if (team_id) {
					this.teamId = team_id;
				}
				if (this.type == 2) {
					this.price = this.pintuanPrice;
				} else {
					this.price = this.product.price;
				}
				this.$refs.lvvpopref.show();
			},
			// 关闭modal弹出框
			toclose() {
				this.$refs.lvvpopref.close();
			},
			// 切换商品规格
			changeSpes(obj) {
				let index = obj.v;
				let key = obj.k;
				//type = 1是立即购买，2是拼团购买
				let tmp_default_spes_desc = JSON.parse(this.product.default_spes_desc);
				if (tmp_default_spes_desc[index][key].hasOwnProperty('product_id') && tmp_default_spes_desc[index]
					[key].product_id) {
					let data = {
						id: tmp_default_spes_desc[index][key].product_id,
						type: 'pintuan' //商品类型
					};
					let userToken = this.$db.get('userToken');
					if (userToken) {
						data['token'] = userToken;
					}
					this.$api.getProductInfo(data, res => {
						if (res.status == true) {
							// 切换规格判断可购买数量
							this.buyNum = res.data.stock > this.minBuyNum ? this.minBuyNum : res.data.stock;
							this.product = this.spesClassHandle(res.data);
							//products.price = _this.$common.moneySub(products.price,_this.discount_amount);
							if (this.type == 2) {
								//拼团
								this.product.mktprice = this.product.price;//原价
								this.price = this.pintuanPrice = this.$common.moneySub(this.product.price, this.discount_amount);
							} else {
								// this.price = this.pintuanPrice = this.product.price;
								this.price = this.product.price;
							}
						}
					});
					uni.showLoading({
						title: '加载中'
					});
					setTimeout(function() {
						uni.hideLoading();
					}, 1000);
				}
			},
			// 多规格样式统一处理
			spesClassHandle(products) {
				// 判断是否是多规格 (是否有默认规格)
				if (products.hasOwnProperty('default_spes_desc')) {
					let spes = products.default_spes_desc;
					for (let key in spes) {
						for (let i in spes[key]) {
							if (spes[key][i].hasOwnProperty('is_default') && spes[key][i].is_default === true) {
								this.$set(spes[key][i], 'cla', 'pop-m-item selected');
							} else if (spes[key][i].hasOwnProperty('product_id') && spes[key][i].product_id) {
								this.$set(spes[key][i], 'cla', 'pop-m-item not-selected');
							} else {
								this.$set(spes[key][i], 'cla', 'pop-m-item none');
							}
						}
					}
					spes = JSON.stringify(spes).replace(/\./g,'====');
					products.default_spes_desc = spes;
				}
				return products;
			},
			// 购买数量加减操作
			bindChange(val) {
				this.buyNum = val;
			},
			// 商品收藏/取消
			collection() {
				let data = {
					goods_id: this.goodsInfo.id
				};
				this.$api.goodsCollection(data, res => {
					if (res.status) {
						this.isfav = !this.isfav;
						this.$common.successToShow(res.msg);
					} else {
						this.$common.errorToShow(res.msg);
					}
				});
			},
			// tab点击切换
			onClickItem(index) {
				if (this.current !== index) {
					this.current = index;
				}
			},
			// 获取商品参数信息
			getGoodsParams() {
				this.$api.goodsParams({
						id: this.goodsId
					},
					res => {
						if (res.status == true) {
							this.goodsParams = res.data;
						}
					}
				);
			},
			// 获取商品评论信息
			getGoodsComments() {
				let data = {
					page: this.goodsComments.page,
					limit: this.goodsComments.limit,
					goods_id: this.goodsId
				};

				this.goodsComments.loadStatus = 'loading';

				this.$api.goodsComment(data, res => {
					if (res.status == true) {
						let _list = res.data.list;

						// 如果评论没有图片 在这块作处理否则控制台报错
						_list.forEach(item => {
							item.ctime = this.$common.timeToDate(item.ctime);
							if (!item.hasOwnProperty('images_url')) {
								this.$set(item, 'images_url', []);
							}
						});

						this.goodsComments.list = [...this.goodsComments.list, ..._list];
						// 根据count数量判断是否还有数据
						if (res.data.count > this.goodsComments.list.length) {
							this.goodsComments.loadStatus = 'more';
							this.goodsComments.page++;
						} else {
							this.goodsComments.loadStatus = 'noMore';
						}
					} else {
						this.$common.errorToShow(res.msg);
					}
				});
			},
			// 添加商品浏览足迹
			goodsBrowsing() {
				let data = {
					goods_id: this.goodsInfo.id
				};

				this.$api.addGoodsBrowsing(data, res => {});
			},
			// 立即购买
			buyNow() {
				if (this.buyNum > 0) {
					let data = {
						product_id: this.product.id,
						nums: this.buyNum,
						order_type: this.type
					};
					this.$api.addCart(data, res => {
						if (res.status) {
							this.toclose();
							let cartIds = res.data;
							if (this.teamId == 0) {
								this.$common.navigateTo('/pages/goods/place-order/index?cart_ids=' + JSON.stringify(cartIds) + '&order_type=' +
									this.type);
							} else {
								this.$common.navigateTo('/pages/goods/place-order/index?cart_ids=' + JSON.stringify(cartIds) + '&order_type=' +
									this.type + '&team_id=' + this.teamId);
							}
						} else {
							this.toclose();
							this.$common.errorToShow(res.msg);
						}
					});
				}
			},
			// 购物车页面跳转
			redirectCart() {
				uni.switchTab({
					url: '/pages/cart/index/index'
				});
			},
			trigger(e) {
				this.content[e.index].active = !e.item.active;
				uni.switchTab({
					url: e.item.url
				});
			},
			// 跳转到h5分享页面
			goShare() {
				this.$refs.share.show();
			},
			closeShare() {
				this.$refs.share.close();
			},
			// 拼团弹出层
			pintuanShow() {
				this.$refs.pintuanpop.show();
			},
			// 图片点击放大
			clickImg(imgs) {
				// 预览图片
				uni.previewImage({
					urls: imgs.split()
				});
			},
			//在线客服,只有手机号的，请自己替换为手机号
			showChat() {
				// #ifdef H5
				let _this = this;
				window._AIHECONG('ini', {
					entId: this.config.ent_id,
					button: false,
					appearance: {
						panelMobile: {
							tone: '#FF7159',
							sideMargin: 30,
							ratio: 'part',
							headHeight: 50
						}
					}
				});
				//传递客户信息
				window._AIHECONG('customer', {
					head: _this.userInfo.avatar,
					名称: _this.userInfo.nickname,
					手机: _this.userInfo.mobile
				});
				window._AIHECONG('showChat');
				// #endif

				// 客服页面
				// #ifdef APP-PLUS || APP-PLUS-NVUE
				this.$common.navigateTo('../customer_service/index');
				// #endif

				// 头条系客服
				// #ifdef MP-TOUTIAO
				if (this.shopMobile != 0) {
					let _this = this;
					tt.makePhoneCall({
						phoneNumber: this.shopMobile.toString(),
						success(res) {},
						fail(res) {}
					});
				} else {
					_this.$common.errorToShow('暂无设置客服电话');
				}
				// #endif
			},
			//获取分享URL
			getShareUrl() {
				let data = {
					client: 2,
					url: '/pages/share/jump',
					type: 1,
					page: 3,
					params: {
						goods_id: this.goodsId,
						team_id: this.teamId
					}
				};
				let userToken = this.$db.get('userToken');
				if (userToken && userToken != '') {
					data['token'] = userToken;
				}
				this.$api.share(data, res => {
					this.shareUrl = res.data;
				});
			}
		},
		watch: {
			goodsId: {
				handler() {
					this.getShareUrl();
				},
				deep: true
			},
			teamId: {
				handler() {
					this.getShareUrl();
				},
				deep: true
			}
		},
		//分享
		onShareAppMessage() {
			return {
				title: this.goodsInfo.name,
				// #ifdef MP-ALIPAY
				desc: this.goodsInfo.brief,
				// #endif
				imageUrl: this.goodsInfo.album[0],
				path: this.shareUrl
			};
		},
		onPageScroll(e) {
			this.barTitle = e.scrollTop > 100 ? '商品详情' : ''
			this.scrollData = e
		},
	};
</script>

<style>
	.content-top {
		padding-bottom: 40rpx;
	}
	.swiper {
		height: 750upx;
	}

	.goods-top {
		border-bottom: 0;
	}

	.goods-top .goods-price {
		font-size: 38upx;
	}

	.cost-price {
		font-size: 28upx !important;
		bottom: -10upx;
		color: #999;
		text-decoration: line-through;
	}

	.goods-top .cell-item-ft {
		font-size: 20upx;
		color: #666;
	}

	.goods-details {
		padding-top: 16upx;
	}

	.goods-details .cell-hd-title {
		width: 620upx;
	}

	.goods-details .cell-hd-title .cell-hd-title-view {
		width: 100%;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		overflow: hidden;
	}

	.goods-details .cell-hd-title .cell-hd-title-view:last-child {
		margin-top: 10upx;
	}

	.goods-details .cell-item-ft {
		top: 42upx;
	}

	.goods-title-item .cell-item-hd {
		min-width: 60upx;
		color: #666;
		font-size: 24upx;
	}

	.goods-title-item .cell-item-bd {
		color: #333;
		font-size: 24upx;
		display: block;
	}

	.goods-title-item .cell-bd-text {
		bottom: 0;
	}

	.cell-bd-view {
		position: relative;
		overflow: hidden;
	}

	.cell-bd-view:first-child {
		margin-bottom: 8upx;
	}

	.goods-title-item-ic {
		width: 22upx;
		height: 22upx;
		position: absolute;
		top: 50%;
		transform: translateY(-50%);
		/* #ifdef MP-ALIPAY */
		background-size: 100% 100%;
		/* #endif */
	}

	.cell-bd-view .cell-bd-text {
		margin-left: 30upx;
	}

	.goods-content {
		margin-top: 26upx;
		background-color: #fff;
		padding: 26upx 0;
	}

	.goods-content-c {}

	.goods-parameter {
		padding: 10upx 26upx;
	}

	.goods-bottom,
	.pop-b {
		background-color: #fff;
		position: fixed;
		bottom: 0;
		height: 90upx;
		width: 100%;
		overflow: hidden;
		box-shadow: 0 0 20upx #ccc;
	}

	.goods-bottom button {
		height: 100%;
		width: 29%;
		float: left;
	}

	.goods-bottom-ic {
		display: inline-block;
		position: relative;
		text-align: center;
		height: 100%;
		width: 14%;
		float: left;
		font-size: 22upx;
		color: #666;
	}

	.goods-bottom-ic .icon {
		position: relative;
		top: 6upx;
		/* #ifdef MP-ALIPAY */
		background-size: 100% 100%;
		/* #endif */
	}

	.goods-bottom .btn-g {
		color: #333;
		background-color: #d9d9d9;
	}

	.goods-parameter .cell-item {
		border-bottom: none;
		margin-left: 0;
	}

	.goods-parameter .cell-item-hd {
		color: #333;
		font-size: 24upx;
	}

	.goods-parameter .cell-item-bd {
		color: #999;
	}

	.goods-parameter .cell-item-bd .cell-bd-text {
		bottom: 0;
	}

	.goods-parameter .cell-bd-text {
		margin-left: 0;
	}

	.pop-t {
		position: relative;
		padding: 30upx 26upx;
		border-bottom: 2upx solid #f3f3f3;
	}

	.goods-img {
		width: 160upx;
		height: 160upx;
		position: absolute;
		top: -20upx;
		background-color: #fff;
		border-radius: 6upx;
		border: 2upx solid #fff;
	}

	.goods-img image {
		height: 100%;
		width: 100%;
	}

	.goods-information {
		width: 420upx;
		display: inline-block;
		margin-left: 180upx;
	}

	.pop-goods-name {
		width: 100%;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		display: block;
		font-size: 24upx;
		margin-bottom: 20upx;
	}

	.pop-goods-price {
		font-size: 30upx;
	}

	.close-btn {
		width: 40upx;
		height: 40upx;
		border-radius: 50%;
		display: inline-block;
		position: absolute;
		right: 30upx;
	}

	.close-btn image {
		width: 100%;
		height: 100%;
	}

	.pop-m {
		font-size: 28upx;
		margin-bottom: 90upx;
	}

	.goods-specs,
	.goods-number {
		padding: 26upx;
		border-top: 1px solid #f3f3f3;
	}

	.goods-specs:first-child {
		border: none;
	}

	.pop-m-title {
		margin-right: 10upx;
		color: #666;
	}

	.pop-m-bd {
		overflow: hidden;
		margin-top: 10upx;
	}

	.pop-m-item {
		display: inline-block;
		float: left;
		padding: 6upx 16upx;
		background-color: #fff;
		color: #333;
		margin-right: 16upx;
		margin-bottom: 10upx;
	}

	.selected {
		border: 2upx solid #333;
		background-color: #333;
		color: #fff;
	}

	.not-selected {
		border: 2upx solid #ccc;
	}

	.none {
		border: 2upx dashed #ccc;
		color: #888;
	}

	.pop-m-bd-in {
		display: inline-block;
	}

	.badge {
		top: 2upx;
		left: 62upx;
	}

	.goods-assess .user-head-img {
		width: 80upx;
		height: 80upx;
		border-radius: 50%;
	}

	.goods-assess .cell-item-bd {
		padding-right: 0;
	}

	.goods-assess .cell-bd-text {
		margin: 0;
	}

	.goods-assess .cell-bd-text.color-9 {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		max-width: 440upx;
	}

	.gai-body {}

	.gai-body-text {
		font-size: 26upx;
		color: #333;
		padding: 0 26upx;
		word-wrap: break-word;
	}

	.gai-body-img {
		overflow: hidden;
		padding: 20upx 26upx;
	}

	.gai-body-img image {
		width: 220upx;
		height: 220upx;
		float: left;
		margin-right: 19upx;
		margin-bottom: 18upx;
	}

	.gai-body-img image:nth-child(3n) {
		margin-right: 0;
	}

	.redstar {
		width: 24rpx;
		height: 24rpx;
		padding: 2rpx;
	}

	.mask-share-wechat {
		display: inline-block;
		background-color: #fff;
		padding: 0;
	}

	.mask-share-wechat:after {
		border: none;
	}

	.right-ball {
		position: fixed;
		right: 30upx;
		bottom: 300upx;
		z-index: 999;
		text-align: center;
		padding: 14upx 0;
		width: 80upx;
		height: 80upx;
		font-size: 24upx;
		color: #fff;
		background-color: rgba(0, 0, 0, 0.5);
		border-radius: 50%;
	}

	.share-pop {
		height: 300upx;
		width: 100%;
		display: flex;
	}

	.share-item {
		flex: 1;
		text-align: center;
		font-size: 26upx;
		color: #333;
		padding: 20upx 0;
	}

	.comment-none {
		text-align: center;
		padding: 200upx 0;
	}

	.comment-none-img {
		width: 274upx;
		height: 274upx;
	}

	.price-salesvolume {
		width: 100%;
		height: 112upx;
		padding: 0 0 0 26upx;
		overflow: hidden;
		color: #a5a5a5;
		background-color: rgb(252, 226, 80);
		position: relative;
	}

	.commodity-price {
		width: 224upx;
		display: inline-block;
		float: left;
	}

	.current-price {
		font-size: 40upx;
		color: #ff7159;
		display: block;
		line-height: 1.5;
	}

	.cost-price {
		font-size: 26upx;
		text-decoration: line-through;
		display: block;
	}

	.commodity-salesvolume {
		width: 240upx;
		display: inline-block;
		font-size: 22upx;
		float: left;
		padding: 16upx 0;
	}

	.commodity-salesvolume>text {
		display: block;
	}

	.commodity-time-img {
		display: block;
		width: 0;
		height: 0;
		border-width: 56upx 28upx 56upx 0;
		border-style: solid;
		border-color: transparent #ff7159 transparent transparent;
		/*透明 黄 透明 透明 */
		float: right;
	}

	.commodity-time {
		display: inline-block;
		width: 220upx;
		height: 100%;
		text-align: center;
		font-size: 24upx;
		background-color: #ff7159;
		padding: 16upx 0 18upx;
		color: #ff7159;
		float: right;
	}

	.commodity-time>text {
		color: rgb(252, 226, 80);
	}

	.commodity-day>text {
		display: inline-block;
		background-color: rgb(255, 212, 176);
		color: rgb(255, 115, 0);
		padding: 0 6upx;
		border-radius: 6upx;
	}

	.nav-back {
		width: 100%;
		height: 44px;
		/* #ifndef MP-WEIXIN */
		padding: 12px 12px 0;
		/* #endif */
		/* #ifdef MP-WEIXIN */
		padding: 26px 12px 0;
		/* #endif */

		position: fixed;
		top: 0;
		background-color: rgba(255, 255, 255, 0);
		z-index: 98;
	}

	.back-btn {
		height: 32px;
		width: 32px;
		border-radius: 50%;
		background-color: rgba(255, 255, 255, 0.8);
	}

	.back-btn .icon {
		height: 20px;
		width: 20px;
		position: relative;
		top: 50%;
		left: 46%;
		transform: translate(-50%, -50%);
	}

	.seller-content {
		background-color: #f8f8f8;
		margin: 0 13px 15px;
		padding: 10px;
		color: #6e6e6e;
		border-radius: 4px;
	}

	.seller-content-top {
		font-weight: bold;
		margin-bottom: 6px;
	}

	.seller-content-img {
		width: 20px;
		height: 20px;
		vertical-align: middle;
		margin-right: 4px;
	}

	.tl {
		width: 70% !important;
	}

	.groupHeight {
		height: 122upx !important;
	}

	.group-swiper-c {
		height: 242upx;
	}

	.group-swiper-c .swiper-item .cell-item {
		height: 50%;
	}

	.group-swiper-c .swiper-item .cell-item .user-head-img {
		width: 80upx;
		height: 80upx;
		border-radius: 50%;
	}

	.group-swiper-c .swiper-item .cell-item .cell-hd-title {
		/* position: absolute;
	top: 50%;
	left: 100upx;
	transform: translateY(-50%); */
		max-width: 200upx;
		width: 100%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		flex: 1;
	}

	.group-swiper-c .swiper-item .cell-item .cell-item-bd {
		min-width: 150upx;
		/* max-width: 200upx; */
		/* padding-right: 134upx; */
		text-align: center;
		display: block;
	}

	.group-swiper-c .swiper-item .cell-item .cell-item-bd .cell-bd-view {
		margin-bottom: 0;
	}

	.group-swiper-c .swiper-item .cell-item .cell-item-bd .cell-bd-text {
		float: none;
	}

	.group-swiper-c .commodity-day>text {
		background: none !important;
		padding: 0;
	}

	.group-swiper-c .swiper-item .cell-item .cell-item-ft .btn {
		font-size: 26upx;
		color: #fff;
		background-color: #ff7159;
		text-align: center;
	}

	.btn-content {
		line-height: 1.2;
		position: relative;
		top: 49%;
		transform: translateY(-50%);
	}

	.ig-top {
		text-align: center;
		background-color: #fff;
		padding: 20upx 26upx;
		width: 690upx;
		min-height: 90upx;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
	}

	.ig-top-t,
	.ig-top-m {
		margin-bottom: 20upx;
	}

	.ig-top-t>view {
		display: inline-block;
		padding: 0 10upx;
		color: #999;
	}

	.user-head-img-c {
		position: relative;
		width: 80upx;
		height: 80upx;
		border-radius: 50%;
		margin-right: 20upx;
		box-sizing: border-box;
		display: inline-block;
		border: 1px solid #f3f3f3;
	}

	.user-head-img-tip {
		position: absolute;
		top: -6upx;
		left: -10upx;
		display: inline-block;
		background-color: #ff7159;
		color: #fff;
		font-size: 22upx;
		z-index: 98;
		padding: 0 10upx;
		border-radius: 10upx;
		transform: scale(0.8);
	}

	.user-head-img-c .user-head-img {
		width: 100%;
		height: 100%;
		border-radius: 50%;
	}

	.user-head-img-c:first-child {
		border: 1px solid #ff7159;
	}

	.uhihn {
		width: 80upx;
		height: 80upx;
		border-radius: 50%;
		display: inline-block;
		border: 2upx dashed #e1e1e1;
		text-align: center;
		color: #d1d1d1;
		font-size: 40upx;
		box-sizing: border-box;
		position: relative;
	}

	.uhihn>text {
		position: absolute;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
	}

	.igtb-top {
		font-size: 32upx;
		color: #333;
		margin-bottom: 16upx;
	}

	.igtb-mid {
		margin-bottom: 16upx;
	}

	.igtb-mid .btn {
		width: 100%;
		background-color: #ff7159;
		color: #fff;
	}

	.igtb-bot {
		font-size: 24upx;
		color: #666;
	}

	/* #ifdef MP-WEIXIN */
	.weiContact {
		background-color: #fff;
		border: none;
		width: 14% !important;
	}

	.weiContact::after {
		border: none;
	}

	.weiContact>view {
		position: absolute;
		top: 45rpx;
		left: 50%;
		transform: translateX(-50%);
	}

	/* #endif */
</style>
