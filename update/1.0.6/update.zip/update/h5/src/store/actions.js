export const saveStore = ({commit}, info) => commit('store', info)

export const saveStoreTab = ({commit}, tab) => commit('storeTab', tab)

export const saveShip = ({commit}, info) => commit('ship', info)
