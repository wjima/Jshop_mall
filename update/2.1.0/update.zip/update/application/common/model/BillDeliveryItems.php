<?php
// +----------------------------------------------------------------------
// | JSHOP [ 小程序商城 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2019 https://www.jihainet.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: keinx <keinx@jihainet.com>
// +----------------------------------------------------------------------
namespace app\common\model;

/**
 * 发货详单
 * Class BillDeliveryItems
 * @package app\common\model
 * @author keinx
 */
class BillDeliveryItems extends Common
{

}