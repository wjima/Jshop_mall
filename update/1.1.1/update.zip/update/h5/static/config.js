window.host = 'https://b2c.jihainet.com';
window.entId = '';
