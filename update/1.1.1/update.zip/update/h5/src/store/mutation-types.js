export const SHOP_CONFIG = 'SHOP_CONFIG'
