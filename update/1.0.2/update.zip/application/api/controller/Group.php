<?php

namespace app\api\controller;

use app\common\controller\Api;
use Request;
use app\common\model\Goods as GoodsModel;
use app\common\model\Products;
use app\common\model\promotion;

/***
 * 团购秒杀活动接口
 */
class Group extends Api
{
    /**
     * 获取活动列表接口
     */
    public function getList(){

    }



}