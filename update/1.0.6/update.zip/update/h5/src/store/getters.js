export const storeInfo = state => state.storeInfo
export const storeTab = state => state.storeTab
export const shipInfo = state => state.shipInfo
