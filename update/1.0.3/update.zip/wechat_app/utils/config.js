module.exports = {
  app_id: '',
  session_key: '',
  api_url: 'http://www.b2c.com/',
  cdn_url: 'http://www.b2c.com/',
  default_image: '',
  app_title: 'Jshop云商',
  app_description: 'Jshop云商',
  app_logo: 'https://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEKhQDbaWe1HfkwEibibAHDadWs5Y4ZzVKbms8ksL1jcK601vDIZIUYx2ubmB8SQVFUNFQuVbzFnBy8Q/0',
  list_limit:10,
  image_max:5,
  store_type:2
}