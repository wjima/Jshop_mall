export const state = {
    storeInfo: {}, // 门店地址
    shipInfo: {}, // 收货地址
    storeTab: 0, // 门店默认tab页
}
