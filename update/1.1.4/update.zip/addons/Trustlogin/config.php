<?php
return [
    'weixin'=>[
        'title'=>'微信快捷登录',
        'value'=>'1'
    ]
];