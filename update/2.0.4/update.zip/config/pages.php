<?php
/**
 *  页面管理相关
 */
return [
   'list'=>[
       'mobile_home'=>'移动端首页',
   ]
];