window.apiUrl = '/api.html';
window.entId = '';
