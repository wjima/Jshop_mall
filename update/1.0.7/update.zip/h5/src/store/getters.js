export const getters = {
    storeInfo: state => state.storeInfo,
    storeTab: state => state.storeTab,
    shipInfo: state => state.shipInfo
}
