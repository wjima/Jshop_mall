window.host = '';
window.entId = '';
