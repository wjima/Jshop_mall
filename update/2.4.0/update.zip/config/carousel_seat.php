<?php
/**
 *
 *  广告位模板配置
 *
 */

return [
    'list' => [
        '首页幻灯片广告位' => 'tpl1_slider',
        '分类页广告位'   => 'tpl1_class_banner1'
    ]
];