// 保存门店地址信息
export const store = (state, info) => state.storeInfo = info

// 保存收货地址信息
export const ship = (state, info) => state.shipInfo = info

// 保存门店tab切换状态
export const storeTab = (state, tab) => state.storeTab = tab
