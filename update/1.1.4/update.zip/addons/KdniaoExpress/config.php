<?php
return [
    'ebusinessid'=>[
        'title'=>'用户ID',
        'value'=>''
    ],
    'apikey'=>[
        'title'=>'API key',
        'value'=>'',
    ],
    'print_name'=>[
        'title'=>'打印机名称',
        'value'=>'',
    ],
    'is_priview'=>[
        'title'=>'是否预览',
        'value'=>'0',
    ],
    'auto_send'=>[
        'title'=>'打印并发货',
        'value'=>'0',
    ],
    'is_notice'=>[
        'title'=>'通知快递',
        'value'=>'1',
    ]
];