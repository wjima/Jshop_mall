<?php
/**
 *
 *  广告位模板配置
 *
 */

return [
    'list' => [
        '首页幻灯片广告位' => 'tpl1_slider',
        '首页广告位1' => 'tpl1_index_banner1',
        '首页广告位2' => 'tpl1_index_banner2',
        '首页广告位3' => 'tpl1_index_banner3',
        '分类页广告位' => 'tpl1_class_banner1'
    ]
];