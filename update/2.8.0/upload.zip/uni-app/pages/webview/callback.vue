<template>
</template>

<script>
export default {
	data() {
		return {
			
		};
	},
	//实现方法，只支持小程序
	/**
	 * 1.微信支付
	 * 2.微信运动
	 * 3.微信红包
	 * 4.微信收藏
	 * 5.收货地址
	 * 6.选择用户已有的发票
	 * */
	 //统一支持方法
	 /***
	 * 1.退出登录
	 * 2.跳转登录
	 * 3.跳转指定页面
	 * */
	 /**
	  * @param {Object} options 
	  * type：类型
	  * method：方法
	  */
	onLoad(options) {
		if(options.type){
			
		}
	},
	methods: {
		
	}
};
</script>

<style></style>
