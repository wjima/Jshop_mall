export const  SAVE_STORE = 'SAVE_STORE'
export const SAVE_SHIP = 'SAVE_SHIP'
export const SAVE_STORE_TAB = 'SAVE_STORE_TAB'

