<?php
/**
 * 平台角色和插件节点权限关联关系表
 */

namespace app\common\model;

class ManageRoleAddonsRel extends Common
{

}