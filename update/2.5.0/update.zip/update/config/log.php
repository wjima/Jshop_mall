<?php
return [
    // 日志记录方式，支持 file socket 或者自定义驱动类
    'type'      => 'file',
    'file_size' => 2097152,
    'max_files' => 10,
];