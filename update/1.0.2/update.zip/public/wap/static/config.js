window.apiUrl = '/index.php/api.html';
window.entId = '';
